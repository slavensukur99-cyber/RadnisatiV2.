package com.radnisati.app

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("radni_sati_data", MODE_PRIVATE) }
    private var month = YearMonth.now()
    private var selectedDate = LocalDate.now()
    private var startTime = ""
    private var endTime = ""
    private var noteText = ""
    private lateinit var root: LinearLayout
    private lateinit var calendarBox: GridLayout
    private lateinit var monthLabel: TextView
    private lateinit var totalsLabel: TextView
    private lateinit var dayLabel: TextView
    private lateinit var startButton: Button
    private lateinit var endButton: Button
    private lateinit var noteInput: EditText
    private lateinit var statusLabel: TextView

    private val bg = Color.rgb(13, 19, 29)
    private val panel = Color.rgb(25, 35, 49)
    private val gold = Color.rgb(224, 184, 105)
    private val white = Color.rgb(240, 243, 248)
    private val muted = Color.rgb(164, 177, 196)
    private val blue = Color.rgb(82, 151, 222)
    private val purple = Color.rgb(160, 151, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
        loadDay(selectedDate)
        renderCalendar()
        updateTotals()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(16))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = TextView(this).apply {
            text = "⌛"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(gold)
            background = rounded(panel, 18)
        }
        header.addView(icon, LinearLayout.LayoutParams(dp(62), dp(62)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titles.addView(label("RadniSati", 25f, white, true))
        titles.addView(label("Tvoje vrijeme. Tvoja evidencija.", 12f, muted))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header)
        content.addView(space(18))

        content.addView(label("MJESEČNI PREGLED", 12f, muted, true))
        val monthRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val prev = button("‹", panel, gold).apply { textSize = 28f }
        val next = button("›", panel, gold).apply { textSize = 28f }
        monthLabel = label("", 21f, white, true)
        monthRow.addView(prev, LinearLayout.LayoutParams(dp(48), dp(46)))
        monthRow.addView(monthLabel, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        monthRow.addView(next, LinearLayout.LayoutParams(dp(48), dp(46)))
        content.addView(monthRow)
        prev.setOnClickListener { month = month.minusMonths(1); selectedDate = month.atDay(1); loadDay(selectedDate); renderCalendar(); updateTotals() }
        next.setOnClickListener { month = month.plusMonths(1); selectedDate = month.atDay(1); loadDay(selectedDate); renderCalendar(); updateTotals() }
        content.addView(space(12))

        val totals = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(panel, 18); setPadding(dp(15), dp(14), dp(15), dp(14)) }
        totals.addView(label("SAŽETAK SATI", 11f, muted, true))
        totalsLabel = label("", 15f, white)
        totals.addView(totalsLabel)
        content.addView(totals)
        content.addView(space(18))

        content.addView(label("KALENDAR", 12f, muted, true))
        calendarBox = GridLayout(this).apply {
            columnCount = 7
            background = rounded(panel, 16)
            setPadding(dp(7), dp(10), dp(7), dp(10))
        }
        content.addView(calendarBox)
        content.addView(space(18))

        val editor = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 18)
            setPadding(dp(15), dp(15), dp(15), dp(15))
        }
        dayLabel = label("", 19f, white, true)
        editor.addView(dayLabel)
        editor.addView(space(12))
        editor.addView(label("Početak smjene", 13f, muted))
        startButton = button("Odaberi vrijeme početka", Color.rgb(34, 48, 65), white)
        editor.addView(startButton, LinearLayout.LayoutParams(-1, dp(48)))
        editor.addView(space(8))
        editor.addView(label("Završetak smjene", 13f, muted))
        endButton = button("Odaberi vrijeme završetka", Color.rgb(34, 48, 65), white)
        editor.addView(endButton, LinearLayout.LayoutParams(-1, dp(48)))
        editor.addView(space(12))
        editor.addView(label("Napomena za ovaj dan", 13f, muted))
        noteInput = EditText(this).apply {
            hint = "Šta si danas radio?"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(17, 25, 37), 12)
        }
        editor.addView(noteInput, LinearLayout.LayoutParams(-1, dp(105)))
        editor.addView(space(12))
        val save = button("Sačuvaj dan", gold, bg)
        editor.addView(save, LinearLayout.LayoutParams(-1, dp(50)))
        statusLabel = label("", 12f, muted)
        editor.addView(statusLabel)
        content.addView(editor)

        startButton.setOnClickListener { chooseTime(true) }
        endButton.setOnClickListener { chooseTime(false) }
        save.setOnClickListener { saveDay() }
    }

    private fun renderCalendar() {
        monthLabel.text = monthName(month)
        calendarBox.removeAllViews()
        val weekdays = listOf("P", "U", "S", "Č", "P", "S", "N")
        weekdays.forEach { day ->
            val tv = label(day, 12f, muted, true).apply { gravity = Gravity.CENTER }
            calendarBox.addView(tv, gridParams())
        }
        val firstOffset = month.atDay(1).dayOfWeek.value - 1
        repeat(firstOffset) { calendarBox.addView(TextView(this), gridParams()) }
        for (day in 1..month.lengthOfMonth()) {
            val date = month.atDay(day)
            val data = readDay(date)
            val isSelected = date == selectedDate
            val hasData = data.optString("start").isNotBlank() || data.optString("note").isNotBlank()
            val tv = TextView(this).apply {
                text = day.toString() + if (hasData) "\n•" else ""
                textSize = if (hasData) 13f else 14f
                gravity = Gravity.CENTER
                setTextColor(if (isSelected) bg else white)
                typeface = if (isSelected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                background = rounded(if (isSelected) gold else if (hasData) Color.rgb(37, 53, 71) else panel, 10)
                setOnClickListener {
                    selectedDate = date
                    loadDay(date)
                    renderCalendar()
                }
            }
            calendarBox.addView(tv, gridParams())
        }
    }

    private fun gridParams(): GridLayout.LayoutParams {
        return GridLayout.LayoutParams().apply {
            width = 0
            height = dp(43)
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
    }

    private fun chooseTime(isStart: Boolean) {
        val current = if (isStart) startTime else endTime
        val parts = current.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: if (isStart) 8 else 16
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        TimePickerDialog(this, { _, h, m ->
            val value = String.format(Locale.US, "%02d:%02d", h, m)
            if (isStart) startTime = value else endTime = value
            updateTimeButtons()
        }, hour, minute, true).show()
    }

    private fun updateTimeButtons() {
        startButton.text = if (startTime.isBlank()) "Odaberi vrijeme početka" else "Početak: $startTime"
        endButton.text = if (endTime.isBlank()) "Odaberi vrijeme završetka" else "Završetak: $endTime"
    }

    private fun loadDay(date: LocalDate) {
        val data = readDay(date)
        startTime = data.optString("start")
        endTime = data.optString("end")
        noteText = data.optString("note")
        if (::dayLabel.isInitialized) {
            dayLabel.text = date.format(DateTimeFormatter.ofPattern("EEEE, d. MMMM yyyy", Locale("sr", "BA")))
            updateTimeButtons()
            noteInput.setText(noteText)
            statusLabel.text = ""
        }
    }

    private fun saveDay() {
        val data = JSONObject()
        data.put("start", startTime)
        data.put("end", endTime)
        data.put("note", noteInput.text.toString())
        prefs.edit().putString(key(selectedDate), data.toString()).apply()
        noteText = noteInput.text.toString()
        statusLabel.text = "✓ Sačuvano na telefonu"
        renderCalendar()
        updateTotals()
    }

    private fun readDay(date: LocalDate): JSONObject =
        try { JSONObject(prefs.getString(key(date), "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    private fun key(date: LocalDate) = "day_${date}"

    private fun updateTotals() {
        var dayMinutes = 0
        var nightMinutes = 0
        var totalDays = 0
        for (d in 1..month.lengthOfMonth()) {
            val date = month.atDay(d)
            val data = readDay(date)
            val s = parseMinutes(data.optString("start"))
            val e = parseMinutes(data.optString("end"))
            if (s >= 0 && e >= 0 && s != e) {
                var end = e
                if (end < s) end += 1440
                val duration = end - s
                totalDays++
                for (minute in s until end) {
                    val minuteOfDay = minute % 1440
                    if (minuteOfDay >= 22 * 60 || minuteOfDay < 6 * 60) nightMinutes++ else dayMinutes++
                }
            }
        }
        totalsLabel.text = "Ukupno: ${formatHours(dayMinutes + nightMinutes)}   •   Dani s radom: $totalDays\n☀ Dnevni rad: ${formatHours(dayMinutes)}     ☾ Noćni rad: ${formatHours(nightMinutes)}"
    }

    private fun parseMinutes(value: String): Int {
        val p = value.split(":")
        if (p.size != 2) return -1
        val h = p[0].toIntOrNull() ?: return -1
        val m = p[1].toIntOrNull() ?: return -1
        return if (h in 0..23 && m in 0..59) h * 60 + m else -1
    }

    private fun formatHours(minutes: Int) = String.format(Locale.US, "%.2f h", minutes / 60.0)

    private fun monthName(value: YearMonth): String {
        val names = listOf("Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar")
        return "${names[value.monthValue - 1]} ${value.year}"
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(text: String, color: Int, textColor: Int) =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            setTextColor(textColor)
            background = rounded(color, 12)
            stateListAnimator = null
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
