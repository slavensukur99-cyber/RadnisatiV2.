# RadniSati

Android aplikacija za evidenciju dnevnog i noćnog rada, sa mjesečnim kalendarom i napomenama po danu.

## Izgradnja APK-a preko GitHub Actions

1. Napravite prazan GitHub repository.
2. Raspakujte sadržaj ovog ZIP-a i otpremite sve fajlove i foldere u root repozitorijuma.
3. Otvorite karticu **Actions**. Ako se build nije pokrenuo automatski, izaberite **Build RadniSati APK** i kliknite **Run workflow**.
4. Otvorite završeni workflow run, pa u sekciji **Artifacts** preuzmite `RadniSati-debug-apk`.
5. Raspakujte preuzeti artefakt i instalirajte `app-debug.apk` na telefon.

## Funkcije
- Mjesečni kalendar i izbor datuma.
- Unos početka i završetka smjene.
- Noćni rad 22:00–06:00; ostali sati se računaju kao dnevni.
- Smjene koje prelaze ponoć.
- Napomena po danu.
- Lokalno čuvanje na telefonu.

Podaci se čuvaju lokalno u aplikaciji. Deinstalacija aplikacije ili brisanje njenih podataka može ih ukloniti; napravite rezervnu kopiju ako su važni.
